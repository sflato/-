<h1> **internetexplorernetexlporenet** </H1>
 <H3> **browser extension** </H3>

<h4> pls enable popups before using <h4>

<h2>*FIREFOX:*<h2>
 1. go to about:debugging
 2. select load temporary ADDON
 3. navigate to the - directory and select manifest.json
 4. the ADDON should now be installed in your toolbar
 5. select the icon and select on to begin your exploration

<h2>*CHROME:*<h2>
 1. go to chrome://extensions
 2. load unpacked
 3. navigate to chrome folder inside - folder
 3. extension should now be functional
