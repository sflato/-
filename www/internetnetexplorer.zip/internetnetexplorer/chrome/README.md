**internetexplorernetexlporenet** 
 **browser extension** 

pls enable popups before using 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*FIREFOX:*
 1. go to about:debugging
 2. select load temporary ADDON
 3. navigate to the - directory and select manifest.json
 4. the ADDON should now be installed in your toolbar
 5. select the icon and select on to begin your exploration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*CHROME:*
 1. go to chrome://extensions
 2. load unpacked
 3. select internetexplorernetexlporenet folder
 4. go to a webpage of ur choice and click the extension icon in the toolbar



